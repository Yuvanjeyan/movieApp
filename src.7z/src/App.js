import "./App.css";
import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from "react-router-dom";
import { useState, useEffect, useCallback } from "react";

import SearchBar from "./components/SearchBar";
import MovieList from "./components/MovieList";
import MovieDetails from "./components/MovieDetails";
import FilterDropDown from "./components/FilterDropDown";
import Favourits from "./components/Favourits";
import { SearchMovie } from "./api";

function AppContent() {
    const navigate = useNavigate();
    const [movies, setMovies] = useState([]);
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);
    const [favourits, setFavourits] = useState([]);

    const [filter, setFilter] = useState("");
    const [searchTerm, setSearchTerm] = useState("movies");

    const [currentPage, setCurrentPage] = useState(1);
    const [totalResults, setTotalResults] = useState(0);

    const moviesPerPage = 12;

    // Fetch movies
    const handleSearch = useCallback(
        async (term = searchTerm, page = 1) => {
            try {
                setLoading(true);
                setError("");
                setSearchTerm(term);
                setCurrentPage(page);

                const data = await SearchMovie(term, filter, page);
                let results = data.Search || [];
                
                // Filter results on client side based on type filter
                if (filter) {
                    results = results.filter(movie => movie.Type.toLowerCase() === filter.toLowerCase());
                }
                
                setMovies(results);
                // Use the API's totalResults, not just the current page
                setTotalResults(Number(data.totalResults) || 0);
            } catch (err) {
                setError("Failed to fetch movies");
            } finally {
                setLoading(false);
            }
        },
        [filter, searchTerm]
    );

    // Load default movies
    useEffect(() => {
        handleSearch("movies", 1);
    }, []);

    // Filter change
    const handleFilterChange = (value) => {
        setFilter(value);
        handleSearch(searchTerm, 1);
    };

    // Handle home click
    const handleHomeClick = () => {
        setFilter("");
        setSearchTerm("movies");
        setMovies([]);
        navigate("/");
        handleSearch("movies", 1);
    };

    const addToFavourits = (movie) => {
        setFavourits((prev) => {
            if (prev.find((m) => m.imdbID === movie.imdbID)) return prev;
            return [...prev, movie];
        });
    };

    const removeFavourits = (id) => {
        setFavourits((prev) => prev.filter((m) => m.imdbID !== id));
    };


    const totalPages = Math.ceil(totalResults / moviesPerPage);

    if (loading) {
        return <h1 className="text-4xl font-bold text-center mt-20 text-gray-300">⏳ Loading movies...</h1>;
    }

    if (error) {
        return (
            <h1 className="text-2xl text-center text-red-600 font-bold mt-20">
                ❌ {error}
            </h1>
        );
    }

    return (
        <>
            {/* HEADER */}
            <header className="App-header">
                <h1 className="app-title">NETFLIX</h1>
                <SearchBar onSearch={(term) => handleSearch(term, 1)} />

                <div className="flex items-center gap-8">
                    <button
                        onClick={handleHomeClick}
                        className="px-10 py-4 text-white font-bold cursor-pointer transition-all duration-300 hover:text-red-500 hover:bg-gray-800 text-gray-300 bg-gray-900 rounded-lg border-2 border-gray-700 hover:border-red-600 uppercase text-base tracking-wider shadow-lg hover:shadow-xl active:scale-95"
                    >
                        🏠 Home
                    </button>

                    <Link
                        to="/favourits"
                        className="px-10 py-4 text-white font-bold cursor-pointer transition-all duration-300 hover:text-red-500 hover:bg-gray-800 text-gray-300 bg-gray-900 rounded-lg border-2 border-gray-700 hover:border-red-600 uppercase text-base tracking-wider shadow-lg hover:shadow-xl"
                    >
                        ⭐ Favourites
                    </Link>

                    <FilterDropDown
                        filter={filter}
                        onFilterChange={handleFilterChange}
                    />
                </div>
            </header>

            {/* MAIN */}
            <main className="px-12 py-20 bg-gradient-to-b from-black via-gray-900 to-black min-h-screen flex-1">
                <Routes>
                    <Route
                        path="/"
                        element={
                            <>
                                <MovieList movies={movies}
                                    onAddFavourits={addToFavourits} />

                                {/* PAGINATION */}
                                {totalPages > 1 && (
                                    <div className="flex justify-center items-center gap-4 mt-16 mb-8 flex-wrap bg-gray-800 p-8 rounded-lg relative z-50">
                                        {/* Prev */}
                                        <button
                                            disabled={currentPage === 1}
                                            onClick={() => handleSearch(searchTerm, currentPage - 1)}
                                            className="w-14 h-14 flex items-center justify-center rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold transition-all duration-300 disabled:opacity-40 disabled:cursor-not-allowed text-xl"
                                        >
                                            ←
                                        </button>

                                        {/* Page numbers(of 5) */}
                                        {Array.from({ length: totalPages }, (_, i) => i + 1)
                                            .filter(
                                                (page) =>
                                                    page >= currentPage - 2 && page <= currentPage + 2
                                            )
                                            .map((page) => (
                                                <button
                                                    key={page}
                                                    onClick={() => handleSearch(searchTerm, page)}
                                                    className={`w-14 h-14 flex items-center justify-center rounded-xl font-bold transition-all duration-300 text-lg ${page === currentPage
                                                        ? "bg-red-600 text-white shadow-lg scale-110"
                                                        : "bg-gray-700 text-white hover:bg-gray-600"
                                                        }`}
                                                >
                                                    {page}
                                                </button>
                                            ))}

                                        {/* Next */}
                                        <button
                                            disabled={currentPage === totalPages}
                                            onClick={() => handleSearch(searchTerm, currentPage + 1)}
                                            className="w-14 h-14 flex items-center justify-center rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold transition-all duration-300 disabled:opacity-40 disabled:cursor-not-allowed text-xl"
                                        >
                                            →
                                        </button>
                                    </div>
                                )}

                            </>
                        }
                    />

                    <Route path="/movie/:id" element={<MovieDetails onAddFavourits={addToFavourits} />} />
                    <Route
                        path="/favourits"
                        element={
                            <Favourits
                                favourits={favourits}
                                onRemoveFavourite={removeFavourits}
                            />
                        }
                    />



                </Routes>

            </main>
        </>
    );
}

function App() {
    return (
        <Router>
            <AppContent />
        </Router>
    );
}

export default App;
