
function FilterDropDown({filter, onFilterChange}) {
    return(
        <select 
            value={filter}
            onChange={(e) => onFilterChange(e.target.value)} 
            className="px-8 py-4 text-white bg-gray-900 border-2 border-gray-600 rounded-lg font-bold text-base focus:border-red-600 focus:outline-none transition-all duration-300 cursor-pointer hover:border-red-600 uppercase tracking-wider shadow-lg hover:shadow-xl"
        >
            <option value="">🎬 All Types</option>
            <option value="movie">🎞️ Movies</option>
            <option value="series">📺 Series</option>
        </select>
    )
}
export default FilterDropDown;