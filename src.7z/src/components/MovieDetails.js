import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { MovieDetails } from "../api";


function MovieDetail({ onAddFavourits }) {
    const { id } = useParams();//get the movie id from the url parameter
    const navigate = useNavigate();
    const [movie, setMovie] = useState(null); //state to store movie details
    const [error, setError] = useState("");// state to store error message

    //fetct the movie details from the api based on the movie id
    useEffect(() => {
        const MovieDetail = async () => {
            try {
                const data = await MovieDetails(id);
                setMovie(data); // Update state with fetched movie details
            } catch (error) {
                setError("Failed to fetch movie details.");
            }
        }
        MovieDetail();
    }, [id])

    const handleAddToFavourites = () => {
        if (movie) {
            onAddFavourits(movie);
            alert(`✅ ${movie.Title} added to favorites!`);
        }
    };

    const handleGoBack = () => {
        navigate(-1);
    };

    const handleGoHome = () => {
        navigate("/");
    };

    //condition if data loading
    if(!movie){
        return <h1 className="text-4xl text-center font-bold mt-20 text-gray-300">⏳ Loading...</h1>;
    }

    if(error){
        return <h1 className="text-2xl text-red-600 font-bold text-center mt-20">❌ Error Loading Movie Details</h1>
    }
    return(
        <div className="min-h-screen py-20 my-8 px-4 md:px-8">
            <div className="max-w-2xl mx-auto px-6 md:px-12">
                <div className="grid md:grid-cols-3 gap-12">
                    {/* Poster */}
                    <div className="md:col-span-1 flex flex-col">
                        <img 
                            src={movie.Poster} 
                            alt={movie.Title}
                            className="w-96 rounded-xl shadow-2xl hover:shadow-3xl transition-shadow duration-300"
                        />
                        <div className="mt-8 flex gap-4 flex-col">
                            <button 
                                onClick={handleAddToFavourites}
                                className="w-full bg-red-600 hover:bg-red-700 active:scale-95 text-white font-bold py-4 px-6 rounded-lg transition-all duration-300 text-base uppercase tracking-wider shadow-lg hover:shadow-xl"
                            >
                                ⭐ Add to Favorites
                            </button>
                            <button 
                                onClick={handleGoBack}
                                className="w-full bg-gray-700 hover:bg-gray-600 active:scale-95 text-white font-bold py-4 px-6 rounded-lg transition-all duration-300 text-base uppercase tracking-wider shadow-lg hover:shadow-xl"
                            >
                                ← Go Back
                            </button>
                            <button 
                                onClick={handleGoHome}
                                className="w-full bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold py-4 px-6 rounded-lg transition-all duration-300 text-base uppercase tracking-wider shadow-lg hover:shadow-xl"
                            >
                                🏠 Home
                            </button>
                        </div>
                    </div>

                    {/* Details */}
                    <div className="md:col-span-2 pl-0 md:pl-8">
                        <h1 className="text-6xl font-bold mb-8 bg-gradient-to-r from-red-500 to-yellow-500 bg-clip-text text-transparent">{movie.Title}</h1>
                        
                        <div className="flex gap-4 mb-10 flex-wrap">
                            <span className="bg-red-600 px-5 py-3 rounded-full text-base font-semibold">📅 {movie.Year}</span>
                            <span className="bg-gray-700 px-5 py-3 rounded-full text-base font-semibold">⭐ {movie.imdbRating}/10</span>
                            <span className="bg-gray-700 px-5 py-3 rounded-full text-base font-semibold">🎬 {movie.Type}</span>
                        </div>

                        <div className="mb-10 pb-10 border-b border-gray-600">
                            <h2 className="text-4xl font-bold mb-6">📖 Plot</h2>
                            <p className="text-gray-300 text-xl leading-relaxed">{movie.Plot}</p>
                        </div>

                        <div className="space-y-8">
                            <div className="bg-gray-800 rounded-lg p-8 border-l-4 border-red-600">
                                <h3 className="text-3xl font-bold mb-4 text-red-500">🎬 Genre</h3>
                                <p className="text-gray-300 text-xl">{movie.Genre}</p>
                            </div>

                            <div className="bg-gray-800 rounded-lg p-8 border-l-4 border-red-600">
                                <h3 className="text-3xl font-bold mb-4 text-red-500">👥 Cast</h3>
                                <p className="text-gray-300 text-xl">{movie.Actors}</p>
                            </div>

                            <div className="bg-gray-800 rounded-lg p-8 border-l-4 border-red-600">
                                <h3 className="text-3xl font-bold mb-4 text-red-500">📅 Released</h3>
                                <p className="text-gray-300 text-xl">{movie.Released}</p>
                            </div>

                            <div className="bg-gray-800 rounded-lg p-8 border-l-4 border-red-600">
                                <h3 className="text-3xl font-bold mb-4 text-red-500">👨‍💼 Director</h3>
                                <p className="text-gray-300 text-xl">{movie.Director}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )

}
export default MovieDetail;